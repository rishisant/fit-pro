# include <iostream>
# include <string>
# include <regex>
# include <fstream>     
# include <vector>
# include "functions.h"

using namespace std;