/*# include <iostream>
# include <string>
# include <math.h>
# include <iomanip>
# include <stdio.h>    
# include <stdlib.h>     
# include <time.h>       
# include <chrono>
# include <thread>
# include "functions.h"
# include <fstream>
# include <sstream>

using std::cout;
using std::cin;
using std::endl;
using std::string;
using std::fixed;
using std::setprecision;
using std::ifstream;



int main2 () {
	Company A;
	A.id = 1;
	A.company_name = "Puckett Industries";
	A.abbreviation = "PCK";
	A.purchase_level = 1;
	A.price = 75;
	A.inflation_rate = 1.03;
	A.deflation_rate = 0.85;
	
	Company B;
	B.id = 2;
	B.company_name = "Kash Cows LLC";
	B.abbreviation = "KSH";
	B.purchase_level = 1;
	B.price = 50;
	B.inflation_rate = 1.07;
	B.deflation_rate = 0.84;

	Company C;
	C.id = 3;
	C.company_name = "Larkin Incorporated";
	C.abbreviation = "LAR";
	C.purchase_level = 1;
	C.price = 100;
	C.inflation_rate = 1.17;
	C.deflation_rate = 0.74;

	Company D;
	D.id = 4;
	D.company_name = "Aerofay";
	D.abbreviation = "AER";
	D.purchase_level = 1;
	D.price = 150;
	D.inflation_rate = 1.11;
	D.deflation_rate = 0.87;

	Company E;
	E.id = 5;
	E.company_name = "Fiddler";
	E.abbreviation = "FID";
	E.purchase_level = 1;
	E.price = 200;
	E.inflation_rate = 1.37;
	E.deflation_rate = 0.54;

	cout << "3 companies";
	cout << endl
	<< endl;
	cout << A.purchase_level <<  endl;
}*/